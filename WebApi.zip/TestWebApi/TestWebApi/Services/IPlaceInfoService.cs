﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace TestWebApi.Services
{
    public interface IPlaceInfoService
    {
        int Add(PlaceInfo placeInfo);
        int AddRange(IEnumerable<PlaceInfo> places);
        IEnumerable<PlaceInfo> GetAll();
        PlaceInfo Find(int intZipCode);
        int Remove(int intZipCode);
        int Update(PlaceInfo placeInfo);
    }
}
