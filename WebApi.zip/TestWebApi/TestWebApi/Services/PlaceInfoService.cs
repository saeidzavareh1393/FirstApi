﻿using Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace TestWebApi.Services
{
    public class PlaceInfoService : IPlaceInfoService
    {
        public int Add(PlaceInfo placeInfo)
        {
            string sQry = "INSERT INTO [Countries] ([Country],[Capital],[ZipCode]) " +
                "VALUES('" + placeInfo.Country + "','" + placeInfo.Capital + "','" + placeInfo.ZipCode + "')";
            int retVal=ExecuteCRUDByQuery(sQry);
            return retVal;
        }

        public int AddRange(IEnumerable<PlaceInfo> places)
        {
            string sQry = "INSERT INTO [Countries] ([Country],[Capital],[ZipCode]) VALUES";
            string sVal = "";
            foreach(var place in places)            
              sVal+= "('" + place.Country + "','" + place.Capital + "','" + place.ZipCode + "'),";
            sVal = sVal.TrimEnd(',');
            sQry = sQry + sVal;
            int retVal=ExecuteCRUDByQuery(sQry);
            return retVal;
        }

        public PlaceInfo Find(int intZipCode)
        {
            PlaceInfo placeInfo = null;
            string sQry = "SELECT * FROM [Countries] WHERE [ZipCode]=" + intZipCode;
            DataTable dtPlaceInfo = ExecuteQuery(sQry);
            if (dtPlaceInfo != null)
            {
                DataRow dr = dtPlaceInfo.Rows[0];
                placeInfo = GetPlaceInfoByRow(dr);
            }
            return placeInfo;
        }

        public IEnumerable<PlaceInfo> GetAll()
        {
            List<PlaceInfo> placeInfos = null;
            string sQry = "SELECT * FROM [Countries]";
            DataTable dtPlaceInfo = ExecuteQuery(sQry);           
            if (dtPlaceInfo != null)
            {
                placeInfos = new List<PlaceInfo>();
                foreach (DataRow dr in dtPlaceInfo.Rows)
                  placeInfos.Add(GetPlaceInfoByRow(dr));
            }
            return placeInfos;
        }

        public int Remove(int ZipCode)
        {
            string sQry = "DELETE FROM [Countries] WHERE [ZipCode]=" + ZipCode;
            int retVal=ExecuteCRUDByQuery(sQry);
            return retVal;
        }

        public int Update(PlaceInfo placeInfo)
        {
            string sQry = "UPDATE [Countries] SET [Country]='" + placeInfo.Country + "',[Capital]='" + placeInfo.Capital + "',[ZipCode]='" + placeInfo.ZipCode + "' WHERE [ZipCode]=" + placeInfo.ZipCode;
            int retVal=ExecuteCRUDByQuery(sQry);

           
                      
         return retVal;            
        }


        private int ExecuteCRUDByQuery(string strSql)
        {
            string sConStr = "Data Source= .;Initial Catalog=MyFirstApi;Integrated Security=True";
            SqlConnection conn = null;
            int iR = 0;
            try
            {
                conn = new SqlConnection(sConStr);
                SqlCommand cmd = new SqlCommand(strSql, conn);
                cmd.CommandType = CommandType.Text;
                conn.Open();
                //Execute the command
                iR = cmd.ExecuteNonQuery();
            }
            catch { iR = 0; }
            finally { if (conn.State != 0) conn.Close(); }
            return iR;
        }

        private DataTable ExecuteQuery(string strSql)
        {
            string sConStr = "Data Source=.;Initial Catalog=MyFirstApi;Integrated Security=True";
            SqlConnection conn = null;
            DataTable dt = null;
            try
            {
                conn = new SqlConnection(sConStr);                
                SqlCommand cmd = new SqlCommand(strSql,conn);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                conn.Open();
                dt = new DataTable();
                //Fill the dataset
                da.Fill(dt);
                if (!(dt.Rows.Count > 0)) dt = null;
            }
            catch { dt = null;  }
            finally { if (conn.State != 0) conn.Close(); }
            return dt;
        }

        private PlaceInfo GetPlaceInfoByRow(DataRow dr)
        {
            PlaceInfo placeInfo = new PlaceInfo();
            placeInfo.Id = Convert.ToInt32(dr["Id"]);
            placeInfo.Country = dr["Country"].ToString();
            placeInfo.Capital = dr["Capital"].ToString();
            placeInfo.ZipCode = int.Parse(dr["ZipCode"].ToString());
            return placeInfo;
        }

    }
}
