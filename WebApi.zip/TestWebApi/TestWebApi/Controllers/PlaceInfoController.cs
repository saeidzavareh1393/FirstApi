﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dtx;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;
using TestWebApi.Services;

namespace TestWebApi.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class PlaceInfoController : ControllerBase
    {

        private readonly IPlaceInfoService _placeInfoService;
        public PlaceInfoController(IPlaceInfoService placeInfoService)
        {
            _placeInfoService = placeInfoService;
        }
        // GET api/placeinfo
        [HttpGet]
        public IEnumerable<PlaceInfo> GetPlaceInfos() =>_placeInfoService.GetAll();

        // GET api/placeinfo/id
        [HttpGet("{zipcode}", Name = nameof(GetPlaceInfoById))]
        public IActionResult GetPlaceInfoById(int zipcode)
        {
            PlaceInfo placeInfo = _placeInfoService.Find(zipcode);
            if (placeInfo == null) 
                return NotFound(); 
            else 
                return new ObjectResult(placeInfo);
        }

        // POST api/placeinfo
        [HttpPost]
        public IActionResult PostPlaceInfo([FromBody]PlaceInfo placeinfo)
        {

            
          

       

            if (placeinfo == null) return BadRequest();            
            int retVal=_placeInfoService.Add(placeinfo);            
            if (retVal > 0) return Ok(); else return NotFound();
        }
        // PUT api/placeinfo/guid
        [HttpPut]
        [Microsoft.AspNetCore.Mvc.ProducesResponseType            (type: typeof(Dtx.Result<System.Collections.Generic.IList<Models.PlaceInfo>>),        statusCode: Microsoft.AspNetCore.Http.StatusCodes.Status200OK)]
        public
            async
            System.Threading.Tasks.Task
            <Dtx.Result<System.Collections.Generic.IList<Models.PlaceInfo>>>
        // PutPlaceInfo(int ZipCode,[FromBody] PlaceInfo placeinfo)
        PutPlaceInfo( [FromBody] PlaceInfo placeinfo)
        {


            var result = new FluentResults.Result<System.Collections.Generic.IList<Models.PlaceInfo>>();


            if (_placeInfoService.Find(placeinfo.ZipCode) == null)
            {

                result.WithError(errorMessage: "NotFound");
                // return NotFound(); 
            }
            int retVal = _placeInfoService.Update(placeinfo);

            if (retVal>0)
            {
               
                result.WithSuccess(successMessage: "Success Update Info");
                //return Ok(); 

            }
            else
            {
                result.WithError(errorMessage: "Update is Faild");
                //return NotFound(); 
            }



            return result.ConvertToDtxResult();
        }

        // DELETE api/placeinfo/5
        [HttpDelete]
        [Microsoft.AspNetCore.Mvc.ProducesResponseType            (type: typeof(Dtx.Result<System.Collections.Generic.IList<Models.PlaceInfo>>),  statusCode: Microsoft.AspNetCore.Http.StatusCodes.Status200OK)]
        public  async   System.Threading.Tasks.Task   <Dtx.Result<System.Collections.Generic.IList<Models.PlaceInfo>>>
         Delete(int ZipCode)
        {
            
            var result = new FluentResults.Result<System.Collections.Generic.IList<Models.PlaceInfo>>();

            int retVal =_placeInfoService.Remove(ZipCode);
          //  if (retVal > 0) return Ok(); else return NotFound();


             if (retVal>0)
            {
               
                result.WithSuccess(successMessage: "Deleted Info");
                //return Ok(); 

            }
            else
            {
                result.WithError(errorMessage: "Row NotFound");
                //return NotFound(); 
            }



            return result.ConvertToDtxResult();


        }
    }
}